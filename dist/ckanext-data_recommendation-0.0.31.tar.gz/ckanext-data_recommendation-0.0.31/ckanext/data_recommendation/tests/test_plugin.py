"""Tests for plugin.py."""
import ckanext.data_recommendation.plugin as plugin

def test_plugin():
    pass