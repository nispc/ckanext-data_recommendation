"ckanext-data_recommendation" is a Chinese language data recommendation engine for CKAN, base on a Jieba.

Documentation：https://github.com/dspim
